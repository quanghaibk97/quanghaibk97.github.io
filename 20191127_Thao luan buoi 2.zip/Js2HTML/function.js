function tạoMenu(){
	var ul = document.querySelector("#menu2"),
		li = [
			{
				name:"Trang chủ",
				href:"/"
			},
			{
				name:"Giới thiệu",
				href:"gioi-thieu.html"
			},
			{
				name:"Tin tức",
				href:"tin-tuc.html"
			},
			{
				name:"Sản phẩm",
				href:"san-pham.html"
			},
			{
				name:"Liên hệ",
				href:"lien-he.html"
			}
		];
	for (var i=0; i<li.length; i++) {
		ul.innerHTML += "<li><a class='menucon abc' href='"+li[i].href+"'>"+li[i].name+"</a></li>";
	}
}
